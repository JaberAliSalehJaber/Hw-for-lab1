public class Homework1
{
    public static void main(String[] args) {

        System.out.println("मेरिब");
    }
}
