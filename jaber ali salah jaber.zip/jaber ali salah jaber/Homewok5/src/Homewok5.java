public class Homewok5 {
    public static void main(String[] args)
    {

        System.out.println("+++++++++++++++++++++");
        System.out.println("jaber ali Saleh jaber");
        System.out.println("_____________________");
    }
}
