public class Homewok4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double investment = in.nextDouble();

        double rate = in.nextDouble();

        int year = in.nextInt();

        rate *= 0.01;


        for(int i = 1; i <= year; i++) {


        }
            int formatter = 19;

            if (i >= 10) formatter = 18;
            System.out.printf(i + "%"+formatter+".2f\n", futureInvestmentValue(investment, rate/12, i));
        }
}
